
{{View::make('Admin.header')}}

@yield('content');

{{View::make('Admin.footer')}}